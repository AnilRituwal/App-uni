<template>
  <q-layout view="lHh Lpr lFf">
   <q-page-container>
      <router-view/>
    </q-page-container>
  </q-layout>
</template>

<script>


import { defineComponent } from 'vue'
// import { useQuasar } from 'quasar'

// let $q

export default defineComponent({
  name: 'MainLayout',
  data () {
    return {
      leftDrawerOpen: false,
      //essentialLinks: linksList,
     
    }
  },
  components: {
    //EssentialLink
  },
  methods: {
    
  },
 
  mounted () {
    // $q = useQuasar()
    // $q.dark.toggle()
  }
})
</script>
