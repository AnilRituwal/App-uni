<template>
  <q-page>
    <img src="~assets/wave.png" class="wave">
    <div class="row" style="height: 90vh">
      <div class="col-0 col-md-6 flex justify-center content-center">
        <img src="~assets/login.svg" class="responsive">
      </div>
      <div v-bind:class="{'justify-center': $q.screen.md || $q.screen.sm || $q.screen.xs}" class="col-12 col-md-6 flex content-center">
        <q-card v-bind:style="$q.screen.lt.sm?{'width': '80%'}:{'width':'50%'}">
          <q-card-section>
            <q-avatar size="103px" class="absolute-center shadow-10">
              <img src="~assets/avatar.svg">
            </q-avatar>
          </q-card-section>
          <q-card-section>
            <div class="q-pt-lg">
              <div class="col text-h6 ellipsis flex justify-center">
                <h2 class="text-h2 text-uppercase q-my-none text-weight-regular">Login</h2>
              </div>
            </div>
          </q-card-section>
          <q-card-section>
            <q-form
              class="q-gutter-md"
              @submit.prevent="onLogin"
            >
              <q-input
                v-model="username"
                label="Username"
                lazy-rules
              />

              <q-input
                type="password"
                v-model="password"
                label="Password"
                lazy-rules

              />
            <div>
                <q-btn label="Login" type="submit" color="primary" class="full-width" rounded/>
                <!--  <div class="text-center q-mt-sm q-gutter-lg">
                  <router-link to="/recuperar-senha" class="text-white">Esqueceu a senha?</router-link>
                  <router-link to="/cadastro" class="text-white">Criar conta?</router-link>
                </div>-->
              </div>
            </q-form>
          </q-card-section>
        </q-card>
      </div>
    </div>
  </q-page>
</template>

<script>
import { defineComponent } from 'vue'
import { useStore } from 'vuex'
import { mapMutations, mapActions } from "vuex";
let $store
import { useQuasar } from 'quasar'
let $q
export default defineComponent({
   setup () {
    const $q = useQuasar()

    // calling here; equivalent to when component is created
    //$q.dark.set(true)
  },
  data () {
    return {
        username:'',
        password: '',
      
    }
  },
  methods: {
      ...mapActions({
      login: "Authentication/login",
      getMasterData:"Authentication/getMasterData",
    }),
    onLogin() {
      this.$router.push({ path: 'Home' })
     
    },
  },
  mounted () {
    $store = useStore()
    $q = useQuasar()
  }
})
</script>

<style scoped>
.bg-image {
  background-image: url('src/assets/wpp-login.jpg');
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}
.wave {
  position: fixed;
  height: 100%;
  left: 0;
  bottom: 0;
  z-index: -1;
}
</style>